import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TextInput, Alert } from 'react-native';
import InputPablo from './src/components/InputPablo';
import BotonPablo from './src/components/BotonPablo';
import { useState } from 'react';

export default function App() {

  //state de la app
  const [numero1, setNumero1] = useState()
  const [numero2, setNumero2] = useState()
  const [resultado, setResultado] = useState()
  const [operador, setOperador] = useState()

  const sumar = () => {
    let suma = parseFloat(numero1) + parseFloat(numero2);
    setOperador('+')
    setResultado(suma)
  }

  const restar = () => {
    let resta = parseFloat(numero1) - parseFloat(numero2);
    setOperador('-')
    setResultado(resta)
  }

  const multiplicar = () => {
    let multip = parseFloat(numero1) * parseFloat(numero2);
    setOperador('*')
    setResultado(multip)
  }

  const dividir = () => {
    let division = parseFloat(numero1) / parseFloat(numero2);
    setOperador('/')
    setResultado(division)
  }

  const reset = () => {
    setResultado(0);
    setNumero1(0)
    setNumero2(0)
  }

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Calculadora sencilla</Text>
      <Text style={styles.texto2}>Ingrese dos números y seleccione una operación</Text>

      <View>
        <InputPablo
          title_placeholder="Primer número"
          numero={numero1}
          setNumero={setNumero1}
        />
        <InputPablo
          title_placeholder="Segundo número"
          numero={numero2}
          setNumero={setNumero2}
        />
      </View>
      <View style={styles.containersm}>
        <BotonPablo
          title_button="Sumar"
          action_button={sumar}
        />
        <BotonPablo
          title_button="Restar"
          action_button={restar}
        />
        <BotonPablo
          title_button="Multiplicar"
          action_button={multiplicar}
        />
        <BotonPablo
          title_button="Dividir"
          action_button={dividir}
        />
        <Text style={styles.texto3}>
        {numero1} {operador} {numero2} = {resultado}
      </Text>
      </View>
      <StatusBar style="auto" />
    </View>

  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'start',
    marginTop: "20%",
    gap: 20,
  },
  containersm: {
    flex: 1,
    gap: 10,
  },
  text: {
    fontWeight: 'bold',
    fontSize: 25,
    color: '#88ceeb',
    textAlign:'center'
  },
  texto2: {
    fontWeight: '500',
    textAlign:'center'
  },
  texto3: {
    fontWeight: '500',
    fontSize:18,
    textAlign:'center'
  },
});
