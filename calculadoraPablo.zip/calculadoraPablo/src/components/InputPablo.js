import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, TouchableOpacity, TextInput} from 'react-native';

export default function InputPablo({title_placeholder, numero, setNumero}) {
  return (
 <>
       <TextInput
      style={styles.Input}
      placeholder={title_placeholder}
      keyboardType='number-pad' 
      value={numero}
      onChangeText={setNumero}/>
 </>

 
  );
}

const styles = StyleSheet.create({
    Input:{
      backgroundColor: 'white', 
      width:200, 
      padding:10,
      color:'black', 
      margin:10,
      fontWeight:'800',
      borderRadius:20,
      borderColor:'black',
      borderWidth:1
    }
  });